$(".btn").on("click",function(){
  $('.menu').toggleClass("show");
});




 