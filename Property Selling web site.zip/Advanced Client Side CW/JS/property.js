$( function() {               //this helps to work jquery tabs
    $( "#tabs" ).tabs();
  } );






$(document).ready(function () {       //fucntion of the add favourit button
    $( ".add" ).click(function() {

      try {
          $(this).attr('disabled', true);    //disable the button after the click
          $('.remove').attr('disabled', false);   //remove button will be enable after click the add button

          var addProperty = $(this).closest("div").attr("id")
          var favList = JSON.parse(localStorage.getItem("favouriteList"));  //get the data from local storage

          if (favList == null) {    //if the there are no data the empty array will creat
            favList = [];
          }

          if (favList != null) {
              for (var x = 0; x < favList.length; x++) {

                  if (addProperty == favList[x]) {   // check whether theproperty is already in the storage
                      alert("The property is already in your favourite list");
                      favList = [];   // give an empty array
                  }

              }
          }

          favList.push(addProperty);  //else the property will be add to the local storage
          localStorage.setItem("favouriteList", JSON.stringify(favList));
      }
      catch (e) {

      }

  });
});

$(document).ready(function () {         // function for remove data
  $('.remove').click(function () {

      $(this).attr('disabled', true);   //disable the remove button after the click and enabale the fav button
      $('.add').attr('disabled', false);

      var removeProperty = $(this).closest("div").attr("id");   //closset div tag id
      favList = JSON.parse(localStorage.getItem("favouriteList"));    //get the data

      if (favList != null) {
          for (var x = 0; x < favList.length; x++) {

              if (removeProperty == favList[x]) {     //remove the data from the storage
                  alert("This property is removed from your list.");
                  delete favList[x];
                  localStorage.setItem("favouriteList", JSON.stringify(favList));
                  favList[x] = [];
              }

          }
      }

      if (favList == null) {   //check whether the list is empty if it is empty this will exicute
          alert("The favourites list is empty.");
      }

  });
});







