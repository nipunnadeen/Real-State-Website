








//for price range

$(document).ready(function() {
    $( ".sliderRange" ).slider({
      range: true,
      min: 0,
      max: 10000000,
      values: [ 500000, 900000 ],
      slide: function( event, ui ) {
        $( "#priceRange" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
      }
    });
    $( "#priceRange" ).val( "$" + $( ".sliderRange" ).slider( "values", 0 ) +
      " - $" + $( ".sliderRange" ).slider( "values", 1 ) );
  });


// select menu for type

  $(document).ready( function() {
    
    $( "#property" ).selectmenu();
  } );




//for minimum bedrooms

  $(document).ready( function() {
    var spinner = $( "#spinnermin" ).spinner({min: 0,max:14 });

    if(  isNaN ($(this).val() )){ 
        $(this).prop("value", "0") ; 
    }

  });


//for maximum bedrooms
  $(document).ready( function() {
    var spinner = $( "#spinnermax" ).spinner({min: 0,max:15 });

    if(  isNaN ($(this).val() )){ 
        $(this).prop("value", "1") ; 
    }
  });




  $(document).ready( function() {
    $( "#time" ).selectmenu();

  });





//searching the proprties

$(function() {
	$( "#Search" ).on("click", function(){   //after click the button this fucntion will start
		
		var propType = $("#property").val();  //declare variables and get the  input values
	    var maxBed =  $("#spinnermin").val();
        var minBed =  $("#spinnermax").val();
		var date =  $("#time").val();
		var minPrice = $(".sliderRange").slider("option", "values")[0];
		var maxPrice = $(".sliderRange").slider("option", "values")[1];
		
		var output="<ul>";
		   for (var i in data.properties) {   //loop
			   if (( propType == data.properties[i].type) || (propType=="Any"))  //if user input type is any or what ever this will exicute
			   if (( minBed >= data.properties[i].bedrooms && maxBed <= data.properties[i].bedrooms ))  //if the min bedrooms and max bedrooms correct this will excute
			   if (( date == data.properties[i].added.month) || (date=="Anytime"))  //if the time is correct this will work
			   if (( data.properties[i].price >= minPrice && data.properties[i].price <= maxPrice ))   // check the price range
			   {
				   {
					   {
						   {

                              //out put 
                               output+="<h2><li>" + "£" + data.properties[i].price +"</li></h2>" + "<img src=" + data.properties[i].picture + ">" + "<p>" + data.properties[i].description + "</p>" + "<button class='Sbtn'><a href='" + data.properties[i].url + "'>Visit Page</a></button><hr>"; 
   
						   } } } } }
				output+="</ul>";
				document.getElementById( "Placeholder" ).innerHTML = output; // pass the values to the placeholder 
	
                //css for the visit page button
                $(".Sbtn").css({'border':'3px solid #008CBA',
                'background-color':'white',
                'font-size':'15px',
                'font-family':'sans-serif',            
                'border-radius':'10px',
                'padding':'16px 32px',
                
            });
         
            $(".Sbtn a").css({
           
            'text-decoration':'none',
            'color':'black',
            'font-weight':'bold'
        });


           

    });
});




    // this function for show the user's favourite property list

    $(document).ready(function() {
        $('.view').on('click', function() {


        favList = JSON.parse(localStorage.getItem("favouriteList"));  //get the data from the local storage
        var view = "<ul>";

        if(favList != null) {
            for(var i = 0; i < data.properties.length; i++) {
                for(var j = 0; j < favList.length; j++) {

                    if(data.properties[i].id == favList[j]) {
                        view += "<div class='favDet'><li><a href="+data.properties[i].url+"><img width='165' height='130' src="+data.properties[i].picture+"></a></li></div><br>";
                    }
                    
                }
            }
        }

        view += "</ul>";
        document.getElementById('PlaceholderFav').innerHTML = view; //pass the data to the placeholder
      
        $(".favDet").css({   //css for the favourite properties
        'list-style':'none',
        'box-shadow': '0 8px 10px 0 rgba(0,0,0,0.16),0 5px 10px 0 rgba(0,0,0,0.12)',
        'height':'50%',
        'width':'68%',
        
    });
    

    });    
});

$(document).ready(function() {    //this function is for remove the all favourite properties from local storage
    $('.remove').on('click', function() {

        $('#PlaceholderFav').remove();
        favList = JSON.parse(localStorage.getItem("favouriteList"));  //get the data from the storage and then clear them
        localStorage.clear();

    });
});















    var data = { 

        "properties": [
             {
                 "id":"prop1",
              "type":"House",
                 "bedrooms":3,
              "price":650000,
              "tenure":"Freehold",
              "description":"Attractive three bedroom semi-detached family home situated within 0.5 miles of Petts Wood station with fast trains to London and within easy walking distance of local shops, schools, bus routes and National Trust woodland. The property comprises; two receptions, fitted 18'9 x 10'1 kitchen/breakfast room and conservatory. The property also benefits from having a utility room and cloakroom. To the first floor there are three bedrooms and a family bathroom with separate WC. Additional features include double glazing, gas central heating and a well presented interior...",
              "location":"Petts Wood Road, Petts Wood, Orpington",
              "picture":"propertyImages/prop1pic1small.jpg",
              "url":"Property1.html",
              
                 "added": {
                     "month":"January",
                     "day":12,
                     "year":2018
                 }
              
             },
           {
                 "id":"prop2",
              "type":"Flat",
              "bedrooms":2,
              "price":299995,
              "tenure":"Freehold",
              "description":"Presented in excellent decorative order throughout is this two double bedroom, two bathroom, garden flat. The modern fitted kitchen is open plan to the living room which boasts solid wooden floors and includes integrated appliances including a dishwasher & a washing machine. This large open plan benefits from bi folding doors onto a secluded private courtyard garden. Both bedrooms are double sized, and the family bathroom boasts a matching three piece suite a shower attachment over the bath. There is also a separate wet room. There are walnut doors throughout and wiring for Sky TV/aerial points in the living room/kitchen and both bedrooms. This apartment being only five years old, is still under a 10 year building guarantee...",
              "location":"Crofton Road, Orpington, BR6",
              "picture":"propertyImages/prop2pic1small.jpg",
              "url":"Property2.html",
                 "added": {
                     "month":"September",
                     "day":14,
                     "year":2018
                 }
             },
           {
                 "id":"prop3",
              "type":"villa",
                 "bedrooms":5,
              "price":476100,
              "tenure":"Freehold",
              "description":"This grand and magnificent villa, boasting regal reception rooms and magnificent gardens, has 2 spacious master suites and 6 well- proportioned bedrooms, with staff quarters in the basement. The house has the advantage of a lift and ample off street parking and garaging. Behind is a substantial, 5 bedroom mews house on Cresswell Place with planning permission to extend to 3,000 sq ft, leading to close to 13,000 sq ft for the ensemble before any alterations such as linking both houses....",
              "location":"High Road, Ilford, IG1",
              "picture":"propertyImages/prop3pic1small.jpg",
              "url":"Property3.html",
                 "added": {
                     "month":"November",
                     "day":24,
                     "year":2018
                 }
             },
           {
                 "id":"prop4",
              "type":"House",
                 "bedrooms":7,
              "price":568000,
              "tenure":"Freehold",
              "description":"An exceptional early Victorian house that boasts the space so many strive to achieve in this exclusive location. Located on the southern side of this highly regarded residential street, in the heart of The Boltons Conservation Area. Benefiting from a front and rear garden which connects to the mews house with off street parking for 5 cars, allowing for fantastic security and privacy.....",
              "location":"Prince Regent Street, Newham, E16",
              "picture":"propertyImages/prop4pic1small.jpg",
              "url":"Property4.html",
                 "added": {
                     "month":"April",
                     "day":19,
                     "year":2018
                 }
             },
           {
                 "id":"prop5",
              "type":"villa",
                 "bedrooms":11,
              "price":650100,
              "tenure":"Freehold",
              "description":"A stunning 5925 sq ft duplex villa located within an exclusive and private gated development with concierge service, and underground parking. Arranged over two floors with a grand double height reception room, the property benefits from a beautiful eat in kitchen complete with Gaggenau appliances, second reception room, five bedrooms with en suite bathrooms, massage room, gym and private terrace and a further study and housekeepers quarters with own entrance. The property has state of the art lighting and entertainment system controlled by touch screen pads throughout the property. The development offers a swimming pool and manicured communal gardens......",
              "location":"Green Lane, Seven Kings, IG6",
              "picture":"propertyImages/prop5pic1small.jpg",
              "url":"Property5.html",
                 "added": {
                     "month":"June",
                     "day":10,
                     "year":2018
                 }
             },
           {
                 "id":"prop6",
              "type":"Flat",
                 "bedrooms":9,
              "price":360500,
              "tenure":"Freehold",
              "description":"The flat has been rebuilt throughout and just a few of the many features include a triple volume reception hall, a lift to all floors, large principal reception rooms and a Ballroom of 2,700 sq. ft./250 sq. m. In addition there is a 12m indoor swimming pool with separate gym, changing facilities with both steam and sauna rooms, massage/hairdressing/spa room. The house is well situated on the west side of The Bishops Avenue on the favoured southerly end of the road and is within 500, of East Finchley underground station and 1100m of Kenwood.......",
              "location":"Romford Road, Newham",
              "picture":"propertyImages/prop6pic1small.jpg",
              "url":"Property6.html",
                 "added": {
                     "month":"August",
                     "day":17,
                     "year":2018
                 }
             },
           {
              "id":"prop7",
              "type":"House",
             "bedrooms":6,
              "price":288950,
              "tenure":"Freehold",
              "description":"A stunning freehold house set in the heart of Mayfair. The property has been meticulously developed by Fenton Whelan, one of London`s premier luxury developers and presents an extremely rare opportunity to purchase a spectacular, freehold asset in one of London`s most exclusive addresses. With an emphasis on meticulous detailing the property boasts a south facing aspect, exceptional ceiling heights on every floor, a large lift, 6 bedrooms, a south-west facing roof terrace, a large integrated garage and separate staff accommodation........",
              "location":"Stonley Road, Woodford",
              "picture":"propertyImages/prop7pic1small.jpg",
              "url":"Property7.html",
                 "added": {
                     "month":"March",
                     "day":27,
                     "year":2018
                 }
             }
        ]}









 